#include<process.h>
#include<conio.h>
#include<sema.h>
//int Spawn_Program(const char* program, const char* command);
//int Spawn_With_Path(const char *program, const char *command, const char *path);
//int Create_Semaphore(const char *name, int ival);
//int P(int sem);
//int V(int sem);
//int Destroy_Semaphore(int sem)

 
 
int main(int argc,char** argv)
{


int px=Spawn_Program("/c/PrintX.exe","/c/PrintX.exe");
int po=Spawn_Program("/c/PrintO.exe","/c/PrintO.exe");

//Print("PrintX_pid:%d;PrintO_pid:%d\n",px,po);


/*while(1)
{
if(f0==1&&f1==1){
Destroy_Semaphore(s0);
Destroy_Semaphore(s1);
Destroy_Semaphore(mutex);
Print("\n over!\n");
return 1;
}

}*/
  return 1;
}


