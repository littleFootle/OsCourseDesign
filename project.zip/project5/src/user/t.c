#include <process.h>
#include <conio.h>


int main(int argc,char** argv)
{

  Print("the current thread's pid is %d\n",Get_PID());
//新增系统调用，显示所有线程的pid与优先级
	ShowThreads();
  return 1;
}
