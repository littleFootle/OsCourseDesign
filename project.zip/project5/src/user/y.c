#include <process.h>
#include <conio.h>
#include <geekos/syscall.h>
#include <geekos/errno.h>
#include <geekos/malloc.h>
#include <geekos/ktypes.h>
#include <geekos/string.h>
#define DEFAULT_PATH "/c:/a"
#define ISSPACE(c)((c)=''||(c)=='\t')

int main(int argc,char** argv)
{
  int pid = 0;
  pid = Spawn_Program("/c/long.exe",1);
  Print("the pid is %d\n",pid);
  return 1;
}
