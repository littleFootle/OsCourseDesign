#include<conio.h>
#include<sched.h>

#define BLACK   0
#define BLUE    1
#define GREEN   2
#define CYAN    3
#define RED     4
#define MAGENTA 5
#define AMBER   6
#define GRAY    7
#define BRIGHT  8
#define ATTRIB(bg,fg) ((fg)|((bg)<<4))
#define DEFAULT_ATTRIBUTE ATTRIB(BLACK, GRAY)

int main(int argc, char** argv)
{
    Print("To Exit hit Ctrl + d.\n");

    Keycode keycode;
    while(1)
    {
       //系统调用，读取键盘按键状态,只有当有键值输入时Get_Key才会有返回值
	keycode=Get_Key();
           
        
            if(!( (keycode & KEY_SPECIAL_FLAG) || (keycode & KEY_RELEASE_FLAG)) ) //只处理非特殊按键的按下事件
            {                
                 int asciiCode = keycode &  0xff;    //低8位为Ascii码

                if( (keycode & KEY_CTRL_FLAG)==KEY_CTRL_FLAG  &&  asciiCode=='d')    //按下Ctrl键
                {
			//系统调用，此处为恢复默认渲染熟悉
			Set_Attr(DEFAULT_ATTRIBUTE);
			Print("\ntime:%d\n",Get_Time_Of_Day());

                    Print("\n---------BYE!--------\n");
                    Exit(1);                      
                }else
                {
			Set_Attr((asciiCode%8)+1);
                    Print("%c",(asciiCode=='\r') ? '\n' : asciiCode);
                }
            } 
        }
    
}

