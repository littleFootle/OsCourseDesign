#include<process.h>
#include<conio.h>
#include<sema.h>
#include<sched.h>

 int s0;
 int s1;
 int mutex;
const char *sema0="mysema0";
const char *sema1="mysema1";
const char *sema2="mutex";

int main(int argc,char** argv){
//返回一个semaphoreID
s0=Create_Semaphore(sema0, 2);
s1=Create_Semaphore(sema1, 2);
mutex=Create_Semaphore(sema2, 1);
for(int i=50;i>0;i--)
{

P(s1);
P(mutex);
Print("O");
V(mutex);
V(s0);
}

//P(mutex);	
//Print ("Process PrintO is done at time: %d\n", Get_Time_Of_Day()) ;
//V(mutex);
return 1;
}
